import { Note } from 'src/app/shared/model/Note.model';

export type SelectedNote = Note;
