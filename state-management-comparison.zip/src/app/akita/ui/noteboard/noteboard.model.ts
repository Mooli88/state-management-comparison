import { Note } from '../../state/note/note.model';

export interface Noteboard {
  notes: Note[];
}
