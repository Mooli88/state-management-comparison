export interface Seatch {
  value: string;
}
