export interface Tile {
  rows: number;
  color?: string;
}
